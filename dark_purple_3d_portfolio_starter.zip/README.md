# Dark Purple Creative Portfolio

A responsive, single-file portfolio starter with CSS-based 3D-inspired art, subtle motion, project cards, about, services, and contact sections.

## Personalize before publishing
- Replace `YOUR NAME` in the header and footer.
- Replace `hello@example.com` with your email address.
- Replace the sample project concepts with your real projects, screenshots, and case studies.
- Update the about and services copy to reflect your real work.

## Free publishing with GitHub Pages
1. Sign in to GitHub and create a new public repository (for example, `purple-portfolio`).
2. Upload `index.html` to the repository root.
3. Open repository **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish and open the URL shown in the Pages settings.

No build step, framework, or paid 3D export is required. The hero artwork is CSS-based (3D-inspired) rather than a full WebGL/Spline scene, keeping the starter lightweight and free to host.
